///////////////////////////////////////////////////////////////////////////////
///  BasePath.cpp
///  <TODO: insert file description here>
///
///  @remarks <TODO: insert remarks here>
///
///  @author Yan Qi @date 6/6/2010
///
///  $Id: BasePath.cpp 47 2010-06-07 06:45:09Z yan.qi.asu $
///
///////////////////////////////////////////////////////////////////////////////

#include <vector>
#include "GraphElements.h"
#include "BasePath.h"
// 
// BasePath::BasePath(void)
// {
// }
// 
// BasePath::~BasePath(void)
// {
// }
